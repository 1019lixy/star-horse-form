import { app, BrowserWindow } from 'electron'
import {dirname, join} from 'path'
import {fileURLToPath, URL} from 'url'
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const createWindow = () => {
    // 创建浏览器窗口
    const mainWindow = new BrowserWindow({
        width: 1000,
        height: 800,
        webPreferences: {
            preload: join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
        },
    })

    // 加载应用
    if (process.env.VITE_DEV_SERVER_URL) {
        // 开发环境
        mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL)
        mainWindow.webContents.openDevTools()
    } else {
        // 生产环境
        mainWindow.loadURL(
            new URL('../dist/index.html', 'file://' + __dirname).toString()
        )
    }
}

// 当Electron初始化完成并准备创建浏览器窗口时调用
app.whenReady().then(() => {
    createWindow()

    app.on('activate', () => {
        // 在macOS上，当点击dock图标并且没有其他窗口打开时，通常在应用程序中重新创建一个窗口
        if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
})

// 关闭所有窗口时退出应用
app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
})
