// 预加载脚本在渲染进程加载之前运行，并且可以访问Node.js API
// 它可以用来在渲染进程和主进程之间建立通信桥梁

import { contextBridge, ipcRenderer } from 'electron'

// 向渲染进程暴露API
contextBridge.exposeInMainWorld('electronAPI', {
    // 示例：获取应用版本
    getAppVersion: () => ipcRenderer.invoke('get-app-version'),

    // 可以添加更多需要的API
})
