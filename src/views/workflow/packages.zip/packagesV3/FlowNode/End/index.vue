<template>
  <div class="flow-row">
    <div class="flow-end-box">
      <div class="flow-item"><div class="flow-end">结束</div></div>
    </div>
  </div>
</template>
<script setup lang="ts">
  export default {
    name: 'FlowEndNode',
    components: {},
    data() {
      return {}
    },
    methods: {},
  };
</script>
